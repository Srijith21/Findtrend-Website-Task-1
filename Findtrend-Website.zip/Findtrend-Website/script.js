var sidemenu = document.getElementById("sidemenu") 

function openmenu(){
    sidemenu.style.right = "-10px";
}
function closemenu(){
    sidemenu.style.right = "-210px";
}